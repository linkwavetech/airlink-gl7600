---
permalink: /scripts_pilotControl/

title: "PiloT Power Control Scripts"
---

The real [repository](https://github.com/johnofleek/Pilot/tree/master/scripts_pilotControl) folder contains shell script files which enable the RPi to control the power state of the PiloT board  

