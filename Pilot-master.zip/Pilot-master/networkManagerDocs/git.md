---
title: GIT
---

## Make a Local Copy of the Repo
Copies the latest version of this project that resides on the github system to a local machine

```
git clone http://github.com/johnofleek/Pilot
```


## Upload local copy to Github

Only useful to developers

```
git add .

git commit -m "add HL8548"

git push -u origin master
```



